import React, { useState } from 'react';

const Popup = () => {
  const [fontSize, setFontSize] = useState(16);
  const [darkMode, setDarkMode] = useState(false);

  const handleReadingMode = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        files: ['../content/contentScript.js']
      });
    });
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          document.body.style.backgroundColor = document.body.style.backgroundColor === 'black' ? 'white' : 'black';
          document.body.style.color = document.body.style.color === 'white' ? 'black' : 'white';
        }
      });
    });
  };

  return (
    <div>
      <h1>Reading Mode Enhancer</h1>
      <button onClick={handleReadingMode}>Enable Reading Mode</button>
      <div>
        <label>Font Size: {fontSize}px</label>
        <input 
          type="range" 
          min="12" 
          max="24" 
          value={fontSize} 
          onChange={(e) => setFontSize(e.target.value)} 
        />
      </div>
      <button onClick={toggleDarkMode}>
        {darkMode ? 'Disable Dark Mode' : 'Enable Dark Mode'}
      </button>
    </div>
  );
};

export default Popup;